export function formatNumberWithCommas(n) {
  return Number(n).toLocaleString();
}
