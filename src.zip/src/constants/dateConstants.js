export const MIN_DATE = "2024-01-01";
export const MAX_DATE = "2024-12-31";
export const MONTHS = [
  "1월",
  "2월",
  "3월",
  "4월",
  "5월",
  "6월",
  "7월",
  "8월",
  "9월",
  "10월",
  "11월",
  "12월",
];
// export const COLORS = [
//   "rgb(0, 123, 255)",
//   "rgb(40, 167, 69)",
//   "rgb(220, 53, 69)",
//   "rgb(255, 193, 7)",
//   "rgb(23, 162, 184)",
// ];
